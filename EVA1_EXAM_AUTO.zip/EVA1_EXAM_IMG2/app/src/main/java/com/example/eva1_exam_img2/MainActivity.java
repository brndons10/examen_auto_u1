package com.example.eva1_exam_img2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Surface;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    SeekBar skBr, skBrLand;
    ImageView imagePortrait, img1, img2, img3;
    Thread hilo;

    int speed = 500;

    Handler handlerPort = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            //aqui se puede interactuar con la UI
            //estamos en el hilo principal
            String mensaje = (String) msg.obj;

            switch (mensaje){
                case "0":
                    imagePortrait.setImageResource(R.drawable.a1);
                    break;
                case "1":
                    imagePortrait.setImageResource(R.drawable.a2);
                    break;
                case "2":
                    imagePortrait.setImageResource(R.drawable.a3);
                    break;
                case "3":
                    imagePortrait.setImageResource(R.drawable.a4);
                    break;
                case "4":
                    imagePortrait.setImageResource(R.drawable.a5);
                    break;
                case "5":
                    imagePortrait.setImageResource(R.drawable.a6);
                    break;
                case "6":
                    imagePortrait.setImageResource(R.drawable.a7);
                    break;
            }

        }
    };

    Handler handlerLand = new Handler(){
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            //aqui se puede interactuar con la UI
            //estamos en el hilo principal
            String mensaje = (String) msg.obj;

            switch (mensaje){
                case "0": img1.setImageResource(R.drawable.a1);
                    img2.setImageResource(R.drawable.a2);
                    img3.setImageResource(R.drawable.a3);
                    break;
                case "1": img1.setImageResource(R.drawable.a2);
                    img2.setImageResource(R.drawable.a3);
                    img3.setImageResource(R.drawable.a4);
                    break;
                case "2": img1.setImageResource(R.drawable.a3);
                    img2.setImageResource(R.drawable.a4);
                    img3.setImageResource(R.drawable.a5);
                    break;
                case "3": img1.setImageResource(R.drawable.a4);
                    img2.setImageResource(R.drawable.a5);
                    img3.setImageResource(R.drawable.a6);
                    break;
                case "4": img1.setImageResource(R.drawable.a5);
                    img2.setImageResource(R.drawable.a6);
                    img3.setImageResource(R.drawable.a7);
                    break;
                case "5":  img1.setImageResource(R.drawable.a5);
                    img2.setImageResource(R.drawable.a6);
                    img3.setImageResource(R.drawable.a7);
                    break;
                case "6": img1.setImageResource(R.drawable.a5);
                    img2.setImageResource(R.drawable.a6);
                    img3.setImageResource(R.drawable.a7);
                    break;
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imagePortrait = findViewById(R.id.imgPortrait);
        skBr = findViewById(R.id.seekBar);
        skBrLand = findViewById(R.id.seekBar2);
        img1 = findViewById(R.id.img1);
        img2 = findViewById(R.id.img2);
        img3 = findViewById(R.id.img3);


        int rotacion = getWindowManager().getDefaultDisplay().getRotation();
        if (rotacion == Surface.ROTATION_0 || rotacion == Surface.ROTATION_180) {

            hilo = new Thread(){
                @Override
                public void run() {
                    super.run();
                    //jale en segundo plano
                    int img = 0;
                    while (true){
                        try {

                            Thread.sleep(speed);

                            Message msg = handlerPort.obtainMessage(1, img + "");  //mandarle mensaje al handler
                            handlerPort.sendMessage(msg); //mostrar mensaje
                            img++;
                            if (img == 6)
                                img = 0;

                            //Log.wtf("hilo","hilo"+img);

                        } catch (InterruptedException e) {
                            e.printStackTrace();
                            Log.wtf("asd", e);
                            break;
                        }
                    }
                }
            };
            hilo.start();

            skBr.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

                @Override
                public void onProgressChanged(SeekBar seekBar, final int progress, boolean fromUser) {

                    switch (progress){
                        case 0:
                            speed = 3000;
                            break;
                        case 1:
                            speed = 2500;
                            break;
                        case 2:
                            speed = 2000;
                            break;
                        case 3:
                            speed = 1500;
                            break;
                        case 4:
                            speed = 1000;
                            break;
                        case 5:
                            speed = 500;
                            break;
                        case 6:
                            speed = 0;
                            break;
                    }
                }
                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                }
                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                }
            });
        } else {
            hilo = new Thread(){
                @Override
                public void run() {
                    super.run();
                    //jale en segundo plano
                    int img = 0;
                    while (true){
                        try {

                            Thread.sleep(speed);

                            Message msg = handlerLand.obtainMessage(1, img + "");  //mandarle mensaje al handler
                            handlerLand.sendMessage(msg); //mostrar mensaje
                            img++;
                            if (img == 6)
                                img = 0;

                            //Log.wtf("hilo","hilo"+img);

                        } catch (InterruptedException e) {
                            e.printStackTrace();
                            Log.wtf("asd", e);
                            break;
                        }
                    }
                }
            };
            hilo.start();
            skBrLand.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {



                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                    switch (progress){
                        case 0:
                            speed = 3000;
                            break;
                        case 1:
                            speed = 2500;
                            break;
                        case 2:
                            speed = 2000;
                            break;
                        case 3:
                            speed = 1500;
                            break;
                        case 4:
                            speed = 1000;
                            break;
                        case 5:
                            speed = 500;
                            break;
                        case 6:
                            speed = 0;
                            break;
                    }
                }
                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                }
                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                }
            });

        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        hilo.interrupt();
    }
}
